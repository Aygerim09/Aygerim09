from django.contrib import admin
from . import models
# Register your models here.

admin.site.register(models.Bus_Stop)
admin.site.register(models.Vehicle)
admin.site.register(models.Card)
admin.site.register(models.BackgroundIMG)
admin.site.register(models.Reviews)