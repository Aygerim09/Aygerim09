from django import forms
from . import models


class SearchForm(forms.Form):
    query = forms.CharField()


class TransferForm(forms.Form):
    number = forms.CharField()
    balance = forms.IntegerField()


class ReviewForm(forms.Form):
    content = forms.CharField(widget=forms.Textarea)

