from django.urls import path
from . import views

urlpatterns = [
    path('', views.base_view, name='base'),
    path('routes/', views.routes, name='routes'),
    path('routes/<str:number>/<str:v_type>', views.bus_stops, name='stops'),
    path('transfer/', views.transfer_view, name='transfer'),
    path('add_review/', views.add_review, name='add_review'),
]