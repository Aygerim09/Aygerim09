from django.db import models
from django.contrib.auth.models import User
from account.models import Profile
from django.urls import reverse
import random
# Create your models here.


VEHICLE_TYPE_CHOICES = (('Bus', 'Bus'), ('Trolley bus', 'Trolley bus'))


class Bus_Stop(models.Model):
    name = models.CharField(max_length=100, default='')

    def __str__(self):
        return self.name + " " + str(self.pk)


class Vehicle(models.Model):
    v_type = models.CharField(max_length=20, choices=VEHICLE_TYPE_CHOICES, default='Bus')
    number = models.CharField(max_length=10, default='')
    image = models.ImageField(default='/Users/darkhan/Desktop/City_Bus/media/WhatsApp_Image_2019-11-21_at_20.48.31.jpeg')
    stops = models.ManyToManyField(Bus_Stop, related_name='vehicles')

    def __str__(self):
        return self.number + ' ' + self.v_type

    def get_abaolute_url(self):
        return reverse('stops', args=[self.number, self.v_type])


class Card(models.Model):
    number = models.CharField(max_length=30, default='', blank=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='card')
    profile = models.ForeignKey(Profile, on_delete=models.CASCADE, default=1)
    balance = models.IntegerField()

    def __str__(self):
        return self.user.username + '-' + self.profile.c_type

    def save(self, *args, **kwargs):
        if self.number == '':
            a = str(random.randint(0, 99999999))
            if len(a) < 8:
                a = '0'*(8-len(a)) + a
            self.number = '96439085033' + a
        super(Card, self).save(*args, **kwargs)


class BackgroundIMG(models.Model):
    image = models.ImageField()


class Reviews(models.Model):
    author = models.ForeignKey(User, on_delete=models.CASCADE)
    content = models.TextField()
    date_published = models.DateTimeField(auto_now_add=True)