from django.shortcuts import render, redirect
from . import models
from django.contrib.auth.models import User
from .forms import SearchForm, TransferForm, ReviewForm
# Create your views here.


def base_view(request):
    user = request.user
    img = models.BackgroundIMG.objects.get(id=2)
    try:
        card = models.Card.objects.get(user=user)
    except:
        card = None
    return render(request, 'base.html', {'user': user, 'card': card, 'img': img,
                                         'reviews': models.Reviews.objects.all().order_by('-date_published')})


def add_review(request):
    if request.user in User.objects.all():
        if request.method == 'POST':
            form = ReviewForm(request.POST)
            if form.is_valid():
                review = models.Reviews.objects.create(author=request.user, content=form.cleaned_data['content'])
                return redirect('base')
            else:
                return redirect('add_review')
        else:
            form = ReviewForm()
        return render(request, 'review.html', {'form': form})
    else:
        return redirect('login')


def routes(request):
    if request.user in User.objects.all():
        vehicles = models.Vehicle.objects.all().order_by('number')
        searched_vehicles = None
        if 'query' in request.GET:
            form = SearchForm(request.GET)
            if form.is_valid():
                query = form.cleaned_data['query']
                searched_vehicles = vehicles.filter(number__icontains=query)
                return render(request, 'search.html', {'form': form, 'vehicles': searched_vehicles})
        else:
            form = SearchForm()
            return render(request, 'search.html', {'form': form})
    else:
        return redirect('login')


def bus_stops(request, number, v_type):
    vehicle = models.Vehicle.objects.get(number=number, v_type=v_type)
    return render(request, 'stops.html', {'vehicle': vehicle, 'stops': vehicle.stops})


def transfer_view(request):
    if request.user in User.objects.all():
        card1 = models.Card.objects.get(user=request.user)
        if request.method == 'POST':
            form = TransferForm(request.POST)
            if form.is_valid() and card1.balance >= form.cleaned_data['balance']:
                card2 = models.Card.objects.get(number=form.cleaned_data['number'])
                card2.balance += form.cleaned_data['balance']
                card1.balance -= form.cleaned_data['balance']
                card2.save()
                card1.save()
                return redirect('base')
            else:
                return redirect('transfer')
        else:
            form = TransferForm()
            return render(request, 'transfer.html', {'form': form, 'card1': card1})
    else:
        return redirect('login')
